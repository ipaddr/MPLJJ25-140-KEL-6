package com.example.projectakhirmobileprogramming

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
